/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unisa.diem.oop.myinputconfirm;

import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author leonardorundo
 */
public class InputConfirm extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        
        //raw1
        Label lbl1 = new Label();
        lbl1.setText("input:");
        TextField tfd1 = new TextField();
        
        
        //raw2
        Label lbl2 = new Label();
        TextField tfd2 = new TextField();
        lbl2.setText("confirm input:");
        
        
        
        Button btn = new Button();
        btn.setText("Ok");
        
       
        
        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        
       
        
        
        GridPane.setConstraints(lbl1, 0, 0);
        GridPane.setConstraints(tfd1, 1, 0);
        GridPane.setConstraints(lbl2, 0, 1);
        GridPane.setConstraints(tfd2, 1, 1);
        GridPane.setConstraints(btn, 1, 2);
        
        GridPane.setMargin(lbl1, new Insets(5));
        GridPane.setMargin(tfd1, new Insets(5));
        GridPane.setMargin(lbl2, new Insets(5));
        GridPane.setMargin(tfd2, new Insets(5));
        GridPane.setMargin(btn, new Insets(5));
        
        root.getChildren().addAll(lbl1,tfd1,lbl2,tfd2,btn);
        
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("InputConfirm");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        //Bindings
        
        BooleanBinding ex = Bindings.or(tfd1.textProperty().isEmpty(), tfd1.textProperty().isNotEqualTo(tfd2.textProperty()));
        
        
        
        btn.disableProperty().bind(ex);
        
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
